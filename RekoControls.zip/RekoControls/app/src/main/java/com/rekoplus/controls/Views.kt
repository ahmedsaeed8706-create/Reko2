package com.rekoplus.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class ItemView(ctx: Context, val item: Item) : View(ctx) {
    var pressedState = false
    var edit = false
    var kx = 0f
    var ky = 0f
    var cameraOn = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        var a = if (pressedState) minOf(255, item.alpha + 90) else item.alpha
        if (item.kind == Kind.CAMERA && !cameraOn && !edit) a /= 3
        p.style = Paint.Style.FILL; p.color = item.color; p.alpha = a
        if (item.kind == Kind.JOYSTICK) {
            c.drawCircle(w / 2, h / 2, w / 2 - 2, p)
            p.alpha = minOf(255, a + 70)
            c.drawCircle(w / 2 + kx, h / 2 + ky, w / 5, p)
        } else {
            val shape = if (item.kind == Kind.CAMERA) 1 else item.shape
            when (shape) {
                0 -> c.drawCircle(w / 2, h / 2, minOf(w, h) / 2 - 2, p)
                1 -> c.drawRoundRect(2f, 2f, w - 2, h - 2, minOf(w, h) * 0.22f, minOf(w, h) * 0.22f, p)
                else -> c.drawRect(2f, 2f, w - 2, h - 2, p)
            }
        }
        if (edit) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.WHITE; p.alpha = 255
            c.drawRect(2f, 2f, w - 2, h - 2, p)
        }
        if (item.kind != Kind.JOYSTICK || edit) {
            t.textSize = minOf(minOf(w, h) / 4f, 56f)
            c.drawText(item.label, w / 2, h / 2 - (t.ascent() + t.descent()) / 2, t)
        }
    }
}

class MarkerView(ctx: Context, private val text: String) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        p.style = Paint.Style.FILL; p.color = 0xFFFF9800.toInt(); p.alpha = 200
        c.drawCircle(w / 2, h / 2, w / 2 - 3, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = Color.WHITE; p.alpha = 255
        c.drawCircle(w / 2, h / 2, w / 2 - 3, p)
        c.drawLine(w / 2, 4f, w / 2, h - 4, p); c.drawLine(4f, h / 2, w - 4, h / 2, p)
        t.textSize = w / 4f
        c.drawText(text.take(3), w / 2, h * 0.9f, t)
    }
}
