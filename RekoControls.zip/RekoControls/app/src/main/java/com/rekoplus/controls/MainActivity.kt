package com.rekoplus.controls

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val dens: Float get() = resources.displayMetrics.density

    private fun btn(parent: LinearLayout, text: String, f: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { f() }
        parent.addView(b)
    }

    private fun svc(f: (ControlService) -> Unit) {
        val s = ControlService.inst
        if (s == null) Toast.makeText(this, "فعّل الخدمة أولاً من إمكانية الوصول", Toast.LENGTH_LONG).show()
        else f(s)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val pd = (20 * dens).toInt()
        col.setPadding(pd, pd, pd, pd)
        sv.addView(col)
        setContentView(sv)

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        col.addView(logo, LinearLayout.LayoutParams((96 * dens).toInt(), (96 * dens).toInt()))
        val t = TextView(this)
        t.text = "Reko Controls"
        t.textSize = 26f
        t.setTextColor(Color.WHITE)
        col.addView(t)
        val t2 = TextView(this)
        t2.text = "REKO PLUS"
        t2.setTextColor(0xFFE53935.toInt())
        col.addView(t2)
        status = TextView(this)
        status.setPadding(0, pd / 2, 0, pd / 2)
        col.addView(status)

        btn(col, "1) تفعيل الخدمة (إمكانية الوصول)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(col, "▶ تشغيل Minecraft") {
            val i = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
            if (i == null) Toast.makeText(this, "Minecraft غير مثبتة", Toast.LENGTH_LONG).show() else startActivity(i)
        }
        btn(col, "2) إظهار / إخفاء الأزرار") { svc { it.setShown(!it.shown) } }
        btn(col, "وضع التعديل / اللعب") { svc { it.setEdit(!it.editMode) } }
        btn(col, "+ إضافة زر") { Store.add(this, Kind.BUTTON); ControlService.inst?.rebuild() }
        btn(col, "+ إضافة عصا حركة") { Store.add(this, Kind.JOYSTICK); ControlService.inst?.rebuild() }
        btn(col, "+ إضافة منطقة كاميرا") { Store.add(this, Kind.CAMERA); ControlService.inst?.rebuild() }
        btn(col, "حفظ التخطيط باسم...") {
            val et = EditText(this)
            et.setText("layout1")
            AlertDialog.Builder(this).setTitle("اسم التخطيط").setView(et)
                .setPositiveButton("حفظ") { _, _ -> Store.saveAs(et.text.toString().trim().ifEmpty { "layout" }) }
                .setNegativeButton("إلغاء", null).show()
        }
        btn(col, "تحميل تخطيط محفوظ") {
            val names = Store.names()
            if (names.isEmpty()) Toast.makeText(this, "لا توجد تخطيطات محفوظة", Toast.LENGTH_SHORT).show()
            else AlertDialog.Builder(this).setTitle("اختر تخطيطًا")
                .setItems(names.toTypedArray()) { _, i -> Store.loadFrom(names[i]); ControlService.inst?.rebuild() }.show()
        }
        btn(col, "إعادة التخطيط الافتراضي") { Store.defaults(this); ControlService.inst?.rebuild() }

        val help = TextView(this)
        help.setPadding(0, pd, 0, 0)
        help.text = "طريقة الاستخدام:\n" +
            "• فعّل الخدمة ثم افتح ماين كرافت (فعّل أزرار اللمس الأصلية داخل اللعبة).\n" +
            "• اضغط الشعار العائم لإظهار القائمة، ثم «تعديل».\n" +
            "• في وضع التعديل: اسحب الزر لتحريكه، المس الزر لتعديله، واسحب الدائرة البرتقالية فوق زر ماين كرافت الأصلي المقابل (هذه نقطة اللمس المُرسلة).\n" +
            "• مهم: لا تضع الدائرة البرتقالية تحت زر أو منطقة من أزرار Reko نفسها.\n" +
            "• اضغط «لعب» وابدأ. الإعدادات تُحفظ تلقائيًا."
        col.addView(help)
    }

    override fun onResume() {
        super.onResume()
        status.text = if (ControlService.inst != null) "الخدمة: تعمل ✅" else "الخدمة: غير مفعّلة ❌"
        status.setTextColor(Color.WHITE)
    }
}
