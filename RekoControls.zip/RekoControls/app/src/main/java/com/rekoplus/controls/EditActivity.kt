package com.rekoplus.controls

import android.app.Activity
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*

class EditActivity : Activity() {
    private lateinit var item: Item
    private lateinit var col: LinearLayout
    private lateinit var labelEt: EditText
    private var modeSp: Spinner? = null
    private var dens = 1f

    private fun label(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.setPadding(0, (12 * dens).toInt(), 0, 0)
        col.addView(tv)
    }

    private fun seek(title: String, min: Int, max: Int, cur: Int, onChange: (Int) -> Unit) {
        label(title)
        val s = SeekBar(this)
        s.max = max - min
        s.progress = (cur - min).coerceIn(0, max - min)
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { onChange(p + min) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        col.addView(s)
    }

    private fun spin(title: String, opts: List<String>, sel: Int, onSel: (Int) -> Unit): Spinner {
        label(title)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts)
        sp.setSelection(sel)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        col.addView(sp)
        return sp
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Store.init(this)
        dens = resources.displayMetrics.density
        val id = intent.getIntExtra("id", -1)
        val f = Store.items.firstOrNull { it.id == id }
        if (f == null) { finish(); return }
        item = f

        val sv = ScrollView(this)
        col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val pd = (18 * dens).toInt()
        col.setPadding(pd, pd, pd, pd)
        sv.addView(col)
        setContentView(sv)

        label("الاسم")
        labelEt = EditText(this)
        labelEt.setText(item.label)
        labelEt.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { item.label = s.toString() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(labelEt)

        if (item.kind == Kind.BUTTON) {
            val idx = Store.FUNCS.indexOfFirst { it.first == item.func }.coerceAtLeast(0)
            spin("الوظيفة", Store.FUNCS.map { it.second }, idx) { pos ->
                val fn = Store.FUNCS[pos]
                if (fn.first != item.func) {
                    item.func = fn.first
                    item.label = fn.second
                    item.mode = Store.defMode(fn.first)
                    labelEt.setText(fn.second)
                    modeSp?.setSelection(item.mode)
                }
            }
        }

        if (item.kind == Kind.CAMERA) {
            seek("العرض", 100, 1200, (item.w / dens).toInt()) { item.w = (it * dens).toInt() }
            seek("الارتفاع", 80, 800, (item.h / dens).toInt()) { item.h = (it * dens).toInt() }
        } else {
            seek("الحجم", 40, 320, (item.w / dens).toInt()) { item.w = (it * dens).toInt(); item.h = item.w }
        }
        seek("الشفافية", 20, 255, item.alpha) { item.alpha = it }

        label("اللون")
        val hs = HorizontalScrollView(this)
        val row = LinearLayout(this)
        for (c in Store.COLORS) {
            val v = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(c)
            v.background = g
            v.setOnClickListener { item.color = c }
            val lpp = LinearLayout.LayoutParams((40 * dens).toInt(), (40 * dens).toInt())
            lpp.setMargins(6, 6, 6, 6)
            row.addView(v, lpp)
        }
        hs.addView(row)
        col.addView(hs)

        if (item.kind == Kind.BUTTON) {
            spin("الشكل", listOf("دائرة", "مستطيل دائري", "مربع"), item.shape) { item.shape = it }
            modeSp = spin("نمط الضغط", listOf("ضغط مستمر", "نقرة", "تبديل"), item.mode) { item.mode = it }
        }

        val del = Button(this)
        del.text = "حذف"
        del.setOnClickListener { Store.items.remove(item); finish() }
        col.addView(del)
        val ok = Button(this)
        ok.text = "تم"
        ok.setOnClickListener { finish() }
        col.addView(ok)
    }

    override fun onPause() {
        super.onPause()
        Store.save()
        ControlService.inst?.rebuild()
    }
}
