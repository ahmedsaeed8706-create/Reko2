package com.rekoplus.controls

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object Kind { const val BUTTON = 0; const val JOYSTICK = 1; const val CAMERA = 2 }

class Item(
    var id: Int, var kind: Int, var label: String, var func: String,
    var x: Int, var y: Int, var w: Int, var h: Int,
    var color: Int, var alpha: Int, var shape: Int, var mode: Int,
    var tx: Int, var ty: Int
)

object Store {
    val FUNCS = listOf(
        "JUMP" to "قفز", "ATTACK" to "هجوم", "USE" to "استخدام", "SNEAK" to "تسلل",
        "INVENTORY" to "إنفنتوري", "SLOT_PREV" to "خانة -", "SLOT_NEXT" to "خانة +",
        "FWD" to "أمام", "BACK" to "خلف", "LEFT" to "يسار", "RIGHT" to "يمين",
        "LEFT_CLICK" to "نقر أيسر", "RIGHT_CLICK" to "نقر أيمن",
        "MOUSE_TOGGLE" to "ماوس", "CUSTOM" to "مخصص"
    )
    val COLORS = intArrayOf(
        0xFF2196F3.toInt(), 0xFFE53935.toInt(), 0xFF43A047.toInt(), 0xFFFFB300.toInt(),
        0xFF8E24AA.toInt(), 0xFFFFFFFF.toInt(), 0xFF00ACC1.toInt(), 0xFF757575.toInt()
    )

    var items = ArrayList<Item>()
    var nextId = 1
    private var sp: SharedPreferences? = null

    fun init(c: Context) {
        if (sp != null) return
        sp = c.applicationContext.getSharedPreferences("reko", 0)
        val j = sp!!.getString("cur", null)
        if (j == null) defaults(c) else try { fromJson(j) } catch (e: Exception) { defaults(c) }
    }

    fun defMode(func: String): Int = when (func) {
        "SNEAK" -> 2
        "INVENTORY", "SLOT_PREV", "SLOT_NEXT" -> 1
        else -> 0
    }

    private fun screen(c: Context): Pair<Int, Int> {
        val m = c.resources.displayMetrics
        return Pair(maxOf(m.widthPixels, m.heightPixels), minOf(m.widthPixels, m.heightPixels))
    }

    private fun mk(c: Context, kind: Int, func: String, label: String, fx: Float, fy: Float,
                   sizeDp: Int, tfx: Float, tfy: Float, color: Int): Item {
        val (W, H) = screen(c)
        val s = (sizeDp * c.resources.displayMetrics.density).toInt()
        return Item(nextId++, kind, label, func, (W * fx - s / 2).toInt(), (H * fy - s / 2).toInt(),
            s, s, color, 170, 0, defMode(func), (W * tfx).toInt(), (H * tfy).toInt())
    }

    private fun mkCamera(c: Context): Item {
        val (W, H) = screen(c)
        return Item(nextId++, Kind.CAMERA, "كاميرا", "CAMERA", (W * 0.60f).toInt(), (H * 0.05f).toInt(),
            (W * 0.38f).toInt(), (H * 0.40f).toInt(), COLORS[0], 60, 1, 0, (W * 0.35f).toInt(), (H * 0.30f).toInt())
    }

    fun defaults(c: Context) {
        items = ArrayList(); nextId = 1
        items.add(mk(c, Kind.JOYSTICK, "MOVE", "", 0.30f, 0.68f, 190, 0.12f, 0.72f, COLORS[5]))
        items.add(mk(c, Kind.BUTTON, "JUMP", "قفز", 0.70f, 0.74f, 84, 0.90f, 0.68f, COLORS[2]))
        items.add(mk(c, Kind.BUTTON, "ATTACK", "هجوم", 0.80f, 0.58f, 84, 0.50f, 0.50f, COLORS[1]))
        items.add(mk(c, Kind.BUTTON, "USE", "استخدام", 0.62f, 0.58f, 84, 0.85f, 0.55f, COLORS[0]))
        items.add(mk(c, Kind.BUTTON, "SNEAK", "تسلل", 0.60f, 0.78f, 72, 0.80f, 0.82f, COLORS[3]))
        items.add(mk(c, Kind.BUTTON, "INVENTORY", "إنفنتوري", 0.30f, 0.12f, 72, 0.54f, 0.05f, COLORS[4]))
        items.add(mkCamera(c))
        save()
    }

    fun add(c: Context, kind: Int) {
        when (kind) {
            Kind.JOYSTICK -> items.add(mk(c, Kind.JOYSTICK, "MOVE", "", 0.30f, 0.50f, 190, 0.12f, 0.72f, COLORS[5]))
            Kind.CAMERA -> items.add(mkCamera(c))
            else -> items.add(mk(c, Kind.BUTTON, "CUSTOM", "زر", 0.45f, 0.45f, 80, 0.88f, 0.45f, COLORS[6]))
        }
        save()
    }

    fun save() { sp?.edit()?.putString("cur", toJson())?.apply() }
    fun saveAs(name: String) { sp?.edit()?.putString("L_$name", toJson())?.apply() }
    fun names(): List<String> = sp!!.all.keys.filter { it.startsWith("L_") }.map { it.substring(2) }.sorted()
    fun loadFrom(name: String) {
        val j = sp?.getString("L_$name", null) ?: return
        fromJson(j); save()
    }

    fun toJson(): String {
        val a = JSONArray()
        for (i in items) {
            val o = JSONObject()
            o.put("id", i.id); o.put("kind", i.kind); o.put("label", i.label); o.put("func", i.func)
            o.put("x", i.x); o.put("y", i.y); o.put("w", i.w); o.put("h", i.h)
            o.put("color", i.color); o.put("alpha", i.alpha); o.put("shape", i.shape); o.put("mode", i.mode)
            o.put("tx", i.tx); o.put("ty", i.ty)
            a.put(o)
        }
        return a.toString()
    }

    fun fromJson(s: String) {
        val a = JSONArray(s)
        val list = ArrayList<Item>()
        var n = 1
        for (k in 0 until a.length()) {
            val o = a.getJSONObject(k)
            val it = Item(o.getInt("id"), o.getInt("kind"), o.getString("label"), o.getString("func"),
                o.getInt("x"), o.getInt("y"), o.getInt("w"), o.getInt("h"),
                o.getInt("color"), o.getInt("alpha"), o.getInt("shape"), o.getInt("mode"),
                o.getInt("tx"), o.getInt("ty"))
            list.add(it); n = maxOf(n, it.id + 1)
        }
        items = list; nextId = n
    }
}
