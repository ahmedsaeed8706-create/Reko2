package com.rekoplus.controls

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot

class Hold(var tx: Float, var ty: Float) {
    var px = tx
    var py = ty
    var stroke: GestureDescription.StrokeDescription? = null
    var ending = false
}

class ControlService : AccessibilityService() {
    companion object { var inst: ControlService? = null }

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private val itemViews = HashMap<Int, ItemView>()
    private val extraViews = ArrayList<View>()
    private var handleView: View? = null
    private var handleLp: WLP? = null
    private var editChip: TextView? = null
    private var hideChip: TextView? = null
    var editMode = false
    var shown = true
    var cameraOn = true
    private val holds = HashMap<Int, Hold>()
    private var running = false
    private val dens: Float get() = resources.displayMetrics.density

    private val BASE = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS or
            WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_NOT_TOUCH_MODAL or WLP.FLAG_SPLIT_TOUCH

    override fun onServiceConnected() {
        super.onServiceConnected()
        inst = this
        Store.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildHandle()
        rebuild()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(i: Intent?): Boolean {
        clearAll()
        handleView?.let { rm(it) }
        handleView = null
        inst = null
        return super.onUnbind(i)
    }

    // ---------- windows ----------
    private fun lp(w: Int, h: Int, x: Int, y: Int): WLP {
        val p = WLP(w, h, WLP.TYPE_ACCESSIBILITY_OVERLAY, BASE, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = x; p.y = y
        return p
    }

    private fun rm(v: View) { try { wm.removeView(v) } catch (e: Exception) {} }

    private fun clearAll() {
        for (v in itemViews.values) rm(v)
        itemViews.clear()
        for (v in extraViews) rm(v)
        extraViews.clear()
        holds.clear()
    }

    fun rebuild() {
        clearAll()
        if (shown) {
            val s = (40 * dens).toInt()
            for (item in Store.items.toList()) {
                val v = ItemView(this, item)
                v.edit = editMode
                v.cameraOn = cameraOn
                v.setOnTouchListener { _, ev -> onItemTouch(item, v, ev) }
                val p = lp(item.w, item.h, item.x, item.y)
                if (item.kind == Kind.CAMERA && !cameraOn && !editMode) p.flags = p.flags or WLP.FLAG_NOT_TOUCHABLE
                wm.addView(v, p)
                itemViews[item.id] = v
            }
            if (editMode) {
                for (item in Store.items.toList()) {
                    if (item.func == "MOUSE_TOGGLE") continue
                    val m = MarkerView(this, item.label.ifEmpty { "حركة" })
                    m.setOnTouchListener { _, ev -> onMarkerTouch(item, m, ev) }
                    wm.addView(m, lp(s, s, item.tx - s / 2, item.ty - s / 2))
                    extraViews.add(m)
                }
            }
        }
        handleView?.let { rm(it); wm.addView(it, handleLp) }
        syncChips()
    }

    fun setEdit(b: Boolean) { editMode = b; shown = true; rebuild() }
    fun setShown(b: Boolean) { shown = b; rebuild() }

    private fun syncChips() {
        editChip?.text = if (editMode) "لعب" else "تعديل"
        hideChip?.text = if (shown) "إخفاء" else "إظهار"
    }

    private fun toggleCamera() {
        cameraOn = !cameraOn
        for (item in Store.items) {
            if (item.kind != Kind.CAMERA) continue
            val v = itemViews[item.id] ?: continue
            v.cameraOn = cameraOn
            val p = v.layoutParams as WLP
            p.flags = if (cameraOn || editMode) p.flags and WLP.FLAG_NOT_TOUCHABLE.inv()
            else p.flags or WLP.FLAG_NOT_TOUCHABLE
            wm.updateViewLayout(v, p)
            v.invalidate()
        }
    }

    private fun openEdit(id: Int) {
        val i = Intent(this, EditActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        i.putExtra("id", id)
        startActivity(i)
    }

    // ---------- floating bar ----------
    private fun buildHandle() {
        val d = dens
        val s = (54 * d).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        logo.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(logo, LinearLayout.LayoutParams(s, s))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.visibility = View.GONE
        root.addView(row)

        fun chip(txt: String, f: () -> Unit): TextView {
            val tv = TextView(this)
            tv.text = txt
            tv.setTextColor(Color.WHITE)
            tv.textSize = 13f
            tv.gravity = Gravity.CENTER
            val bg = GradientDrawable()
            bg.setColor(0xDD222222.toInt())
            bg.cornerRadius = 16 * d
            tv.background = bg
            tv.setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
            tv.setOnClickListener { f() }
            val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            p.leftMargin = (6 * d).toInt()
            row.addView(tv, p)
            return tv
        }
        editChip = chip("تعديل") { setEdit(!editMode) }
        chip("+ زر") { Store.add(this, Kind.BUTTON); setEdit(true) }
        hideChip = chip("إخفاء") { setShown(!shown) }
        chip("التطبيق") {
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }

        val p = lp(WLP.WRAP_CONTENT, WLP.WRAP_CONTENT, (20 * d).toInt(), (20 * d).toInt())
        handleLp = p
        handleView = root

        var dx0 = 0f; var dy0 = 0f; var sx = 0; var sy = 0; var mv = false
        logo.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> { dx0 = ev.rawX; dy0 = ev.rawY; sx = p.x; sy = p.y; mv = false }
                MotionEvent.ACTION_MOVE -> {
                    val ddx = (ev.rawX - dx0).toInt(); val ddy = (ev.rawY - dy0).toInt()
                    if (abs(ddx) > 12 || abs(ddy) > 12) mv = true
                    if (mv) { p.x = sx + ddx; p.y = sy + ddy; wm.updateViewLayout(root, p) }
                }
                MotionEvent.ACTION_UP -> {
                    if (!mv) row.visibility = if (row.visibility == View.GONE) View.VISIBLE else View.GONE
                }
            }
            true
        }
        wm.addView(root, p)
    }

    // ---------- touch handling ----------
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    private fun onItemTouch(item: Item, v: ItemView, ev: MotionEvent): Boolean {
        if (editMode) { editTouch(item, v, ev); return true }
        when (item.kind) {
            Kind.JOYSTICK -> joyTouch(item, v, ev)
            Kind.CAMERA -> camTouch(item, ev)
            else -> btnTouch(item, v, ev)
        }
        return true
    }

    private fun editTouch(item: Item, v: ItemView, ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = item.x; startY = item.y; moved = false }
            MotionEvent.ACTION_MOVE -> {
                val dx = (ev.rawX - downX).toInt(); val dy = (ev.rawY - downY).toInt()
                if (abs(dx) > 10 || abs(dy) > 10) moved = true
                if (moved) {
                    item.x = startX + dx; item.y = startY + dy
                    val p = v.layoutParams as WLP
                    p.x = item.x; p.y = item.y
                    wm.updateViewLayout(v, p)
                }
            }
            MotionEvent.ACTION_UP -> { if (moved) Store.save() else openEdit(item.id) }
        }
    }

    private fun onMarkerTouch(item: Item, m: View, ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = item.tx; startY = item.ty }
            MotionEvent.ACTION_MOVE -> {
                item.tx = startX + (ev.rawX - downX).toInt()
                item.ty = startY + (ev.rawY - downY).toInt()
                val p = m.layoutParams as WLP
                p.x = item.tx - p.width / 2; p.y = item.ty - p.height / 2
                wm.updateViewLayout(m, p)
            }
            MotionEvent.ACTION_UP -> Store.save()
        }
        return true
    }

    private fun btnTouch(item: Item, v: ItemView, ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.pressedState = true; v.invalidate()
                if (item.func == "MOUSE_TOGGLE") { toggleCamera(); return }
                val x = item.tx.toFloat(); val y = item.ty.toFloat()
                when (item.mode) {
                    0 -> startHold(item.id, x, y)
                    1 -> { startHold(item.id, x, y); ui.postDelayed({ releaseHold(item.id) }, 90) }
                    else -> {
                        val h = holds[item.id]
                        if (h != null && !h.ending) releaseHold(item.id) else startHold(item.id, x, y)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.pressedState = false; v.invalidate()
                if (item.mode == 0 && item.func != "MOUSE_TOGGLE") releaseHold(item.id)
            }
        }
    }

    private fun joyTouch(item: Item, v: ItemView, ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val r = v.width / 2f
                var dx = ev.x - r; var dy = ev.y - r
                val len = hypot(dx, dy)
                if (len > r) { dx = dx / len * r; dy = dy / len * r }
                v.kx = dx; v.ky = dy; v.invalidate()
                val tx = item.tx + dx; val ty = item.ty + dy
                val h = holds[item.id]
                if (h == null || h.ending) startHold(item.id, tx, ty) else moveHold(item.id, tx, ty)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.kx = 0f; v.ky = 0f; v.invalidate()
                releaseHold(item.id)
            }
        }
    }

    private var camLastX = 0f
    private var camLastY = 0f
    private var camOffX = 0f
    private var camOffY = 0f
    private var camGen = 0
    private fun camKey(item: Item) = item.id + 100000 * (camGen % 2)

    private fun camTouch(item: Item, ev: MotionEvent) {
        if (!cameraOn) return
        val ax = item.tx.toFloat(); val ay = item.ty.toFloat()
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                camLastX = ev.rawX; camLastY = ev.rawY; camOffX = 0f; camOffY = 0f
                startHold(camKey(item), ax, ay)
            }
            MotionEvent.ACTION_MOVE -> {
                camOffX += (ev.rawX - camLastX) * 1.5f
                camOffY += (ev.rawY - camLastY) * 1.5f
                camLastX = ev.rawX; camLastY = ev.rawY
                if (abs(camOffX) > 220 || abs(camOffY) > 220) {
                    releaseHold(camKey(item))
                    camGen++
                    camOffX = 0f; camOffY = 0f
                    startHold(camKey(item), ax, ay)
                } else {
                    moveHold(camKey(item), ax + camOffX, ay + camOffY)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> releaseHold(camKey(item))
        }
    }

    // ---------- gesture injection ----------
    private fun cx(v: Float) = v.coerceIn(1f, (resources.displayMetrics.widthPixels - 2).toFloat())
    private fun cy(v: Float) = v.coerceIn(1f, (resources.displayMetrics.heightPixels - 2).toFloat())

    private fun startHold(id: Int, x: Float, y: Float) {
        val o = holds[id]
        if (o != null) { o.tx = cx(x); o.ty = cy(y); o.ending = false }
        else holds[id] = Hold(cx(x), cy(y))
        kick()
    }

    private fun moveHold(id: Int, x: Float, y: Float) {
        val h = holds[id] ?: return
        if (!h.ending) { h.tx = cx(x); h.ty = cy(y) }
    }

    private fun releaseHold(id: Int) {
        val h = holds[id] ?: return
        h.ending = true
        kick()
    }

    private fun kick() { if (!running) pump() }

    private fun pump() {
        if (holds.isEmpty()) { running = false; return }
        val b = GestureDescription.Builder()
        var n = 0
        val done = ArrayList<Int>()
        for ((id, h) in holds) {
            if (n >= 8) break
            val path = Path()
            path.moveTo(h.px, h.py)
            if (h.tx != h.px || h.ty != h.py) path.lineTo(h.tx, h.ty)
            val cont = !h.ending
            val dur = if (cont) 100L else 30L
            val old = h.stroke
            val ns = if (old == null) GestureDescription.StrokeDescription(path, 0L, dur, cont)
            else old.continueStroke(path, 0L, dur, cont)
            b.addStroke(ns)
            h.stroke = ns; h.px = h.tx; h.py = h.ty
            n++
            if (h.ending) done.add(id)
        }
        for (id in done) holds.remove(id)
        running = true
        val ok = dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { pump() }
            override fun onCancelled(g: GestureDescription?) {
                for (h in holds.values) h.stroke = null
                ui.postDelayed({ pump() }, 30)
            }
        }, null)
        if (!ok) { running = false; holds.clear() }
    }
}
