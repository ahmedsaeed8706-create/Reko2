Reko Controls - REKO PLUS
=========================
1) افتح github.com وأنشئ حسابًا مجانيًا، ثم New repository (اسمه RekoControls).
2) ارفع محتوى هذا المجلد كاملًا (Add file > Upload files) مع المجلد المخفي .github.
3) انتظر 3-5 دقائق (تبويب Actions).
4) افتح قسم Releases في المستودع وحمّل app-debug.apk وثبّته.
لاستبدال الشعار: ضع صورتك باسم logo.png في app/src/main/res/drawable/ قبل الرفع.
